import { getAllPosts, getAllTags } from "@/lib/blog";
import BlogListClient from "@/components/blog/BlogListClient";
import { getMessages, isLocale, type Locale } from "@/lib/i18n";

export default async function BlogPage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale: rawLocale } = await params;
  const locale: Locale = isLocale(rawLocale) ? rawLocale : "en";
  const t = getMessages(locale).blog;

  const posts = getAllPosts();
  const tags = getAllTags(posts);

  return (
    <main className="section-space">
      <section className="container-custom">
        <div className="apple-panel-strong gradient-border relative overflow-hidden rounded-[32px] px-6 py-10 md:px-10 md:py-14">
          <div className="absolute -left-12 top-10 h-28 w-28 rounded-full bg-sky-400/15 blur-3xl" />
          <div className="absolute right-0 top-0 h-36 w-36 rounded-full bg-fuchsia-400/10 blur-3xl" />
          <div className="absolute bottom-0 left-1/3 h-28 w-28 rounded-full bg-cyan-400/10 blur-3xl" />

          <div className="relative z-10 max-w-3xl space-y-5">
            <span className="badge text-soft">{t.eyebrow}</span>

            <div className="space-y-4">
              <h1 className="section-title">{t.title}</h1>

              <p className="max-w-2xl text-base leading-8 text-soft md:text-lg">
                {t.description}
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="container-custom mt-10 space-y-8">
        <div className="apple-panel-strong gradient-border relative overflow-hidden rounded-[28px] p-5 md:p-6">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(255,255,255,0.06),transparent_35%)] opacity-80" />

          <div className="relative z-10">
            <div className="mb-5 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
              <div>
                <p className="text-sm text-muted">{t.filterLabel}</p>
                <h2 className="mt-1 text-xl font-semibold tracking-tight text-foreground">
                  {t.browseTitle}
                </h2>
              </div>

              <p className="text-sm text-soft">{t.postCount(posts.length)}</p>
            </div>

            <BlogListClient posts={posts} tags={tags} locale={locale} />
          </div>
        </div>
      </section>
    </main>
  );
}