export default function Page() {
  return (
    <main className="section-space">
      <div className="container-custom space-y-10">
        <section className="text-center">
          <p className="badge text-muted">Portfolio</p>

          <h1 className="mt-5 text-4xl font-semibold tracking-tight text-foreground sm:text-6xl">
            Build something <span className="hero-gradient">clean & memorable</span>
          </h1>

          <div className="gradient-line mx-auto mt-5 h-px w-28" />

          <p className="mx-auto mt-6 max-w-2xl text-base leading-8 text-soft">
            Global.css の変数だけで、サイト全体の色・カード・境界線・影を一括管理できる構成です。
            Appleっぽい落ち着いた透明感も入れています。
          </p>
        </section>

        <section className="grid gap-6 md:grid-cols-2">
          <div className="apple-panel gradient-border rounded-[28px] p-7">
            <p className="text-sm uppercase tracking-[0.22em] text-muted">
              Theme Utility
            </p>

            <h2 className="mt-4 text-2xl font-semibold text-foreground">
              bg-card / border-border / text-foreground
            </h2>

            <p className="mt-4 leading-7 text-soft">
              これからは <code>text-slate-900</code> や <code>dark:text-white</code> を
              直接書かず、テーマ用クラスを使えば管理しやすくなります。
            </p>

            <div className="mt-6 rounded-2xl border border-border bg-card p-4 shadow-theme">
              <p className="text-sm text-muted">Card Sample</p>
              <p className="mt-2 text-foreground">
                このカードの色は Global.css の変数から来ています。
              </p>
            </div>
          </div>

          <div className="apple-panel-strong rounded-[28px] p-7">
            <p className="text-sm uppercase tracking-[0.22em] text-muted">
              Apple-ish Surface
            </p>

            <h2 className="mt-4 text-2xl font-semibold text-foreground">
              Soft glass surface
            </h2>

            <p className="mt-4 leading-7 text-soft">
              ライトモードでは白系の上品な面、ダークモードでは少し深めのガラス面になります。
              配色は全部変数なので、あとから一気に調整できます。
            </p>

            <div className="mt-6 flex flex-wrap gap-3">
              <button className="rounded-full border border-border bg-card px-5 py-3 text-sm font-medium text-foreground transition hover:scale-[1.02]">
                Secondary
              </button>

              <button className="rounded-full px-5 py-3 text-sm font-semibold text-white shadow-theme transition hover:scale-[1.02]"
                style={{
                  background:
                    "linear-gradient(90deg, var(--accent-1), var(--accent-2), var(--accent-3))",
                }}
              >
                Primary
              </button>
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}